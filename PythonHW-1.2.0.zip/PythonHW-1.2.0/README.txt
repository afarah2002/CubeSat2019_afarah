These problems are ordered alphabetically, and *not* in order of ascending difficulty. Please consult the BWSI-EdX course page for the due dates for the respective problems.

In order to run the auto-grader for these problems, you must install bwsi_grader:

```shell
pip install bwsi_grader
```
